import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class Product {
	product: any = {};
	variationProduct: any = {};
	constructor(){}
}